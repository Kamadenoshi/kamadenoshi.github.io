document.addEventListener("DOMContentLoaded", () => {
  const openDatePicker = document.getElementById("openDatePicker");
  const modal = document.getElementById("datePickerModal");
  const closeModal = document.querySelector(".close");
  const submitDates = document.getElementById("submitDates");
  const quickSelectButtons = document.querySelectorAll(
    ".quick-select-panel button"
  );
  const prevMonthButton = document.getElementById("prevMonth");
  const nextMonthButton = document.getElementById("nextMonth");
  const calendarWrappers = [
    document.getElementById("calendar1"),
    document.getElementById("calendar2"),
    document.getElementById("calendar3"),
  ];

  let selectedDates = [];
  let currentDate = new Date();
  let currentMonth = currentDate.getMonth();
  let currentYear = currentDate.getFullYear();

  const monthNames = [
    "Январь",
    "Февраль",
    "Март",
    "Апрель",
    "Май",
    "Июнь",
    "Июль",
    "Август",
    "Сентябрь",
    "Октябрь",
    "Ноябрь",
    "Декабрь",
  ];

  function renderCalendar(month, year) {
    calendarWrappers.forEach((calendar, index) => {
      renderSingleCalendar(calendar, month + index, year);
    });
  }

  function renderSingleCalendar(calendarElement, month, year) {
    calendarElement.innerHTML = "";
    const firstDay = new Date(year, month, 1).getDay();
    const daysInMonth = new Date(year, month + 1, 0).getDate();

    const calendarHeader = document.createElement("div");
    calendarHeader.classList.add("calendar-header");
    calendarHeader.textContent = `${monthNames[month % 12]} ${
      year + Math.floor(month / 12)
    }`;
    calendarElement.appendChild(calendarHeader);

    const table = document.createElement("table");
    const thead = document.createElement("thead");
    const headerRow = document.createElement("tr");
    ["Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс"].forEach((day) => {
      const th = document.createElement("th");
      th.textContent = day;
      headerRow.appendChild(th);
    });
    thead.appendChild(headerRow);
    table.appendChild(thead);

    const tbody = document.createElement("tbody");
    let date = 1;
    for (let i = 0; i < 6; i++) {
      const row = document.createElement("tr");
      for (let j = 0; j < 7; j++) {
        const cell = document.createElement("td");
        if (i === 0 && j < (firstDay === 0 ? 6 : firstDay - 1)) {
          cell.textContent = "";
        } else if (date > daysInMonth) {
          break;
        } else {
          cell.textContent = date;
          cell.dataset.date = `${year}-${(month + 1)
            .toString()
            .padStart(2, "0")}-${date.toString().padStart(2, "0")}`;
          cell.addEventListener("click", () => selectDate(cell));
          date++;
        }
        row.appendChild(cell);
      }
      tbody.appendChild(row);
    }
    table.appendChild(tbody);
    calendarElement.appendChild(table);

    highlightRange();
  }

  function selectDate(cell) {
    const date = cell.dataset.date;

    if (selectedDates.length === 2) {
      selectedDates = [];
      clearRange();
    }

    selectedDates.push(date);
    cell.classList.add("selected");

    if (selectedDates.length === 2) {
      highlightRange();
      console.log(`Выбран диапазон: ${selectedDates[0]} - ${selectedDates[1]}`);
    }
  }

  function highlightRange() {
    if (selectedDates.length === 2) {
      const [startDate, endDate] = selectedDates.map((d) => new Date(d));
      document.querySelectorAll("td").forEach((cell) => {
        const cellDate = new Date(cell.dataset.date);
        if (cellDate >= startDate && cellDate <= endDate) {
          cell.classList.add("range");
          if (cellDate.getTime() === startDate.getTime()) {
            cell.classList.add("range-start");
          } else if (cellDate.getTime() === endDate.getTime()) {
            cell.classList.add("range-end");
          }
        }
      });
    }
  }

  function clearRange() {
    document.querySelectorAll("td").forEach((cell) => {
      cell.classList.remove("selected", "range", "range-start", "range-end");
    });
  }

  openDatePicker.addEventListener("click", () => {
    modal.style.display = "flex";
  });

  closeModal.addEventListener("click", () => {
    modal.style.display = "none";
  });

  quickSelectButtons.forEach((button) => {
    button.addEventListener("click", () => {
      const now = new Date();
      let startDate, endDate;

      switch (button.dataset.range) {
        case "yesterday":
          startDate = endDate = new Date(now.setDate(now.getDate() - 1));
          break;
        case "today":
          startDate = endDate = new Date();
          break;
        case "last7days":
          endDate = new Date();
          startDate = new Date(now.setDate(now.getDate() - 7));
          break;
        case "last30days":
          endDate = new Date();
          startDate = new Date(now.setDate(now.getDate() - 30));
          break;
        case "last90days":
          endDate = new Date();
          startDate = new Date(now.setDate(now.getDate() - 90));
          break;
        case "fromStart":
          startDate = new Date(2020, 0, 1);
          endDate = new Date();
          break;
      }

      selectedDates = [formatDate(startDate), formatDate(endDate)];
      highlightRange();
      console.log(`Выбран диапазон: ${selectedDates[0]} - ${selectedDates[1]}`);
    });
  });

  submitDates.addEventListener("click", () => {
    console.log(`Выбранные даты: ${selectedDates[0]} - ${selectedDates[1]}`);
    modal.style.display = "none";
  });

  prevMonthButton.addEventListener("click", () => {
    currentMonth -= 3;
    if (currentMonth < 0) {
      currentMonth += 12;
      currentYear--;
    }
    renderCalendar(currentMonth, currentYear);
  });

  nextMonthButton.addEventListener("click", () => {
    currentMonth += 3;
    if (currentMonth > 11) {
      currentMonth -= 12;
      currentYear++;
    }
    renderCalendar(currentMonth, currentYear);
  });

  function formatDate(date) {
    return `${date.getFullYear()}-${(date.getMonth() + 1)
      .toString()
      .padStart(2, "0")}-${date.getDate().toString().padStart(2, "0")}`;
  }

  renderCalendar(currentMonth, currentYear);
});
